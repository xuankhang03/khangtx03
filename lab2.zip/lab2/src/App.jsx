import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Bai1 from './components/bai1-lab1'
import Bai2 from './components/bai2-lab1'
import Headers from './components/Header'
import Footer from './components/Footer'
//lab1bai1
function App() {
  return (
    <div>
    <Headers /> 
    <Bai1 />
    <Bai2 />
  </div>

  
  )



}

export default App;
