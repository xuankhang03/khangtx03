function Bai1() { 
    const firstName = "React"; 
    const lastName = "JS"; 
    return ( 
    <div> 
    <h1>Chào mừng đến với Lab 2</h1> 
    <p>Tổng của 5 + 3 là: {5 + 3}</p> 
    <p>Họ và tên: {firstName + " " + lastName}</p> 
    </div> 

); 
} 
export default Bai1; 