import { Container } from "react-bootstrap"; 
function Footer() { 
return ( 
<Container fluid className="bg-dark text-white text-center py-3"> 
<p>Created by Nguyen Van A</p> 
</Container> 
); 
} 
export default Footer; 